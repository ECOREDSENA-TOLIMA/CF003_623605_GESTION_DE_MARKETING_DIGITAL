module.exports = 'Comunidades virtuales para el marketing'
