<template lang="pug">
.curso-main-container.pb-3
  BannerInterno
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5
    .titulo-principal.color-acento-contenido
      .titulo-principal__numero
        span 2
      h1 Recolección de información
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12
      p Las diferentes actividades empresariales que han sucedido en este siglo, se han enfocado en el manejo de la información y de acuerdo con Ruiz (2007), “hoy en día se tiene tanto acceso a la información que se ha convertido en una desventaja competitiva”. Es importante entender conceptos como datos, información, conocimiento y sistemas de información:

    .row.justify-content-center.mb-5
      .col-xl-3.col-lg-7.col-md-9.col-11.mb-4.mb-xl-0
        .crd_hover_txt(data-aos="flip-left")
          .crd_hover_txt--img
            figure
              img(src="@/assets/curso/temas/tema2/img1.png", alt="alt")
          .crd_hover_txt--body.crd_hover_txt--body2
            .icono  
              img(src="@/assets/curso/temas/tema1/flecha.svg", alt="Imagen decorativa")
            h4.mb-3 Datos
            p.mb-0 Se considera dato a toda información específica y concreta acerca de un elemento, hecho, o situación que permite analizarlos, estudiarlos, diagnosticarlos y conocerlos. Por ejemplo: crecimiento económico del 3%, donde 3% es la expresión que debe analizarse en relación con el contexto “crecimiento económico”.
      .col-xl-3.col-lg-7.col-md-9.col-11.mb-4.mb-xl-0
        .crd_hover_txt(data-aos="flip-left")
          .crd_hover_txt--img
            figure
              img(src="@/assets/curso/temas/tema2/img2.png", alt="alt")
          .crd_hover_txt--body.crd_hover_txt--body2
            .icono  
              img(src="@/assets/curso/temas/tema1/flecha.svg", alt="Imagen decorativa")
            h4.mb-3 Información
            p.mb-0 Se denomina información a la presentación o agrupación de los datos significativos y en conjunto describen eventos, sucesos o eventos y con su procesamiento se puede elaborar un mensaje con sentido crítico.
      .col-xl-3.col-lg-7.col-md-9.col-11.mb-4.mb-xl-0
        .crd_hover_txt(data-aos="flip-left")
          .crd_hover_txt--img
            figure
              img(src="@/assets/curso/temas/tema2/img3.png", alt="alt")
          .crd_hover_txt--body.crd_hover_txt--body2
            .icono  
              img(src="@/assets/curso/temas/tema1/flecha.svg", alt="Imagen decorativa")
            h4.mb-3 Conocimiento
            p.mb-0 Es el resultado de analizar, procesar, comparar y combinar los datos convertidos en información confiable de acuerdo con los intereses de la empresa. De esta forma, el sujeto o empresa pueden argumentar el manejo de la información.
      .col-xl-3.col-lg-7.col-md-9.col-11.mb-4.mb-xl-0
        .crd_hover_txt(data-aos="flip-left")
          .crd_hover_txt--img
            figure
              img(src="@/assets/curso/temas/tema2/img4.png", alt="alt")
          .crd_hover_txt--body.crd_hover_txt--body2
            .icono  
              img(src="@/assets/curso/temas/tema1/flecha.svg", alt="Imagen decorativa")
            h4.mb-3 Sistemas de información
            p.mb-0 El sistema de información (SI) es una serie de elementos que se relacionan y se integran (#[i hardware] y #[i software]) para recopilar, almacenar y procesar información que apoye la toma de decisiones. Adicionalmente, los sistemas de información apoyan el control y supervisión de la misma.

    Separador
    .row
      .col-xl-12
    #t_2_1.titulo-segundo.color-acento-contenido(data-aos="zoom-in-left")
      h2.my-5 2.1 Tipos de investigación
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12
      p La investigación de mercado es un proceso que aplica la empresa para obtener información del sector mediante la búsqueda y análisis de datos, bien sea de fuentes primarias o secundarias. En la investigación de mercados se pueden distinguir dos tipos de investigación: investigación de mercados cualitativa e investigación de mercados cuantitativa.

    .row.align-items-center.mb-4
      .col-auto.pe-0.desktop(style="z-index:2")
        figure
          img(src='@/assets/curso/temas/tema1/imgtitulo.svg').m-auto
      .col-auto.bg-c8(style="z-index:1;color:#4B6280")
        .p-2
          h3.mb-0 Investigación de mercados cualitativa
          
    
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12
        p Se denomina investigación de mercados cualitativa al conjunto de técnicas que se utilizan para obtener una visión general del comportamiento y la percepción de las personas sobre un tema en particular. Según Báez y Pérez (2014) la investigación cualitativa es:
    
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-10
        figure
            img(src="@/assets/curso/temas/tema2/img5.jpg", alt="alt")
        .cajon.colorcajon24.p-3          
          p El conjunto de todas las cosas que se hacen para seguir la pista a los mercados y encontrar los rasgos que distinguen a las personas (cliente, consumidor, organización…) y a las cosas (productos, bienes, servicios, sectores de actividad) sus propiedades y atributos, sean estos naturales y/o adquiridos.
    
    .row.justify-content-center.align-items-center
      .col-lg-10.col-md-10.mb-4.mb-md-0(data-aos="flip-left")
        .titulo-sexto.color-acento-contenido.offset-0
          h5 Tabla 1.
          span  #[i  Ventajas y desventajas de la investigación de mercados cualitativa]
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-10.mb-4
        .tabla-c.color-acento-contenido
          .tabla-b__header
            h5.mb-0 Investigación de mercados cualitativa
          table
            thead
              tr
                th.text-center Ventajas 
                th.text-center Desventajas
            tbody
              tr
                td 
                  ul.lista-ul.mb-0
                    li.mb-0
                      i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                      | No necesita un plan estrictamente diseñado.
                td 
                  ul.lista-ul.mb-0
                    li.mb-0
                      i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                      | Se interpreta la investigación con una visión sesgada.
              tr
                td
                  ul.lista-ul.mb-0
                    li.mb-0
                      i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                      | Se adquiere información detallada y enriquecida en descripciones.
                td
                  ul.lista-ul.mb-0
                    li.mb-0
                      i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                      | Consume mucho tiempo.
              tr
                td
                  ul.lista-ul.mb-0
                    li.mb-0
                      i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                      | Observa el contexto y el sentido social.
                td
                  ul.lista-ul.mb-0
                    li.mb-0
                      i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                      | Puede tardar meses.

              tr
                td
                  ul.lista-ul.mb-0
                    li.mb-0
                      i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                      | La comunicación es horizontal.
                td
                  ul.lista-ul.mb-0
                    li.mb-0
                      i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                      | Hay demasiado involucramiento por parte del investigador.
      .col-lg-10
        p Para concretar, la investigación cualitativa pretende profundizar en los conceptos y valores, detectar motivadores y valorar las reacciones y para su ejecución requiere un soporte de psicología.
    
    .row.align-items-center.mb-4
      .col-auto.pe-0.desktop(style="z-index:2")
        figure
          img(src='@/assets/curso/temas/tema1/imgtitulo.svg').m-auto       
      .col-auto.bg-c8(style="z-index:1;color:#4B6280")
        .p-2
          h3.mb-0 Investigación de mercados cuantitativa 

    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12
      p Se denomina investigación de mercados cuantitativa aquella que busca obtener información acerca de la población objeto o público objetivo. Los datos obtenidos como resultado de la investigación se pueden analizar con modelos matemáticos o estadísticos, entre otras ayudas técnicas.

    .row.justify-content-center.align-items-center
      .col-lg-10.col-md-10.mb-4.mb-md-0(data-aos="flip-left")
        .titulo-sexto.color-acento-contenido.offset-0
          h5 Tabla 2.
          span  #[i  Ventajas y desventajas de la investigación de mercados cuantitativa]
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-10.mb-4
        .tabla-c.color-acento-contenido
          .tabla-b__header
            h5.mb-0 Investigación de mercados cuantitativa
          table
            thead
              tr
                th.text-center Ventajas 
                th.text-center Desventajas
            tbody
              tr
                td 
                  ul.lista-ul.mb-0
                    li.mb-0
                      i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                      | Permite al investigador medir y analizar datos.
                td 
                  ul.lista-ul.mb-0
                    li.mb-0
                      i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                      | El contexto del estudio o experimento es ignorado.
              tr
                td
                  ul.lista-ul.mb-0
                    li.mb-0
                      i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                      | Relación variable independiente y dependiente.
                td
                  ul.lista-ul.mb-0
                    li.mb-0
                      i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                      | No hay discusiones en los resultados, porque son exactos.
              tr
                td
                  ul.lista-ul.mb-0
                    li.mb-0
                      i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                      | Objetividad en la investigación.
                td
                  ul.lista-ul.mb-0
                    li.mb-0
                      i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                      | Debe estudiarse una amplia porción de la población.
              tr
                td
                  ul.lista-ul.mb-0
                    li.mb-0
                      i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                      | Puede utilizarse para probar hipótesis.
                td
                  
      .col-lg-10
        p Para sintetizar, la investigación cuantitativa pretende cuantificar, establecer proporciones y diferencias e importancia relativa y para su ejecución requiere un soporte estadístico.
        .cajon.color-secundario.p-4.mb-4
          p Se invita a observar el siguiente video para ampliar el concepto de investigación y la clasificación según el objeto de estudio:          
    
    .row.justify-content-center.align-items-center.md-5   
      .col-lg-12(data-aos="fade-left")     
        figure
          .video          
            iframe(width="560" height="315" src="https://www.youtube.com/embed/GCZ503I6r0k" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen)

    Separador
    .row
      .col-xl-12
    #t_2_2.titulo-segundo.color-acento-contenido(data-aos="zoom-in-left")
      h2.my-5 2.2  Técnicas de recolección de información

    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12
      p Cuando se realiza una investigación, es necesario obtener una información del mercado y definir la manera como se obtiene esa información, eso se denomina recolección de datos. Una vez definido el método de recolección, se procede a realizar el trabajo de campo.

      p El trabajo de campo, requiere varias actividades previas para su ejecución, como la identificación, formación y seguimiento de las personas que recopilan los datos, selección adecuada de la modalidad (presencial o virtual) y la técnica para la obtención de los datos, bien sea la observación, entrevistas telefónicas, entrevistas personales, por correo o electrónicas, encuestas, entre otras.  
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-10
        .bloque-texto-g.bloque-texto-g--inverso.color-primario.p-3.p-sm-4.p-md-5
          .bloque-texto-g__img(
            :style="{'background-image': `url(${require('@/assets/curso/temas/tema2/img6.jpg')})`}"
          )
          .bloque-texto-g__texto.p-4
            p.mb-0 Hay diferentes métodos y técnicas para obtener la información del mercado que puede ser importante en la investigación. La selección del método de recolección de información, depende del enfoque de la estrategia, las variables seleccionadas, la exactitud esperada, la zona de recolección y las capacidades del encuestador.
    
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-10
        p Las siguientes técnicas reúnen y ayudan a organizar la información de acuerdo con el objetivo trazado (Caro, 2019).
    
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-10
        LineaTiempoD.color-primario
          .row(numero="1" titulo="Observación")
            .col-md-12.mb-4.mb-md-0
              p La observación consiste en obtener información del entorno, objeto o hecho en el cual enfocamos la investigación, mediante el registro de datos para su diagnóstico. En esta técnica, el investigador forma parte de la situación observada, persona o grupo de personas, analizando sus comportamientos. 
            .col-md-12
              figure
                img(src='@/assets/curso/temas/tema2/img7.jpg', alt='Imagen decorativa')
          .row(numero="2" titulo="Observación directa")
            .col-md-12.mb-4.mb-md-0
              p El investigador se encuentra en el lugar de los hechos sin realizar algún tipo de intervención para no alterar la situación o los datos. Sus características son: 
              .cajon.colorpaso.p-3
                ul.lista-ul.mb-0
                  li.mb-0
                    i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                    | No es intrusiva: el foco de investigación (objeto observado) no es intervenido.
                  li.mb-0
                    i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                    | No es participativa: no se hacen recomendaciones a los participantes para no alterar los datos.
                  li.mb-0
                    i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                    | Es de larga duración: con la finalidad de que los hechos se desarrollen de forma natural.
                  li.mb-0
                    i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                    | Resultados variados: en este método, los resultados pueden ser tanto reales como condicionados.
                  li.mb-0
                    i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                    | Participante: el investigador participa de la acción a la vez que obtiene los datos.
                  li.mb-0
                    i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                    | No participante: el investigador no interactúa con la población objeto de investigación.
                  li.mb-0

            .col-md-12
              figure
                img(src='@/assets/curso/temas/tema2/img8.jpg', alt='Imagen decorativa')
          .row(numero="3" titulo="Observación indirecta")
            .col-md-12.mb-4.mb-md-0
              p Aquí el investigador recolecta la información a partir de fuentes secundarias como bases de datos, documentación digital, tesis de grados, entrevistas realizadas, entre otros. La observación indirecta se caracteriza porque:
              .cajon.colorpaso.p-3
                ul.lista-ul.mb-0
                  li.mb-0
                    i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                    | Se basa en fuentes secundarias.
                  li.mb-0
                    i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                    | No es intrusiva, pues no se interactúa de forma directa con la investigación.
                  li.mb-0
                    i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                    | Los datos obtenidos son esencialmente cualitativos.
            .col-md-12
              figure
                img(src='@/assets/curso/temas/tema2/img9.jpg', alt='Imagen decorativa')
          .row(numero="4" titulo="Entrevista")
            .col-md-12.mb-4.mb-md-0
              p Es una técnica muy utilizada para obtener información. Consiste en una conversación realizada entre dos o más personas por medio de preguntas que pueden ser abiertas o cerradas. Se elabora un guion que permita orientar la conversación hacia la obtención de la información, puede ser presencial, telefónica o en línea.
              p Usualmente, en la entrevista se presentan preguntas abiertas para que la persona entrevistada brinde la mayor cantidad de información posible, mientras que, en las preguntas cerradas, las respuestas son limitadas y no hay lugar para alternativas.

            .col-md-12
              figure
                img(src='@/assets/curso/temas/tema2/img10.jpg', alt='Imagen decorativa')
          .row(numero="5" titulo="Entrevistas estructuradas o enfocadas")
            .col-md-12.mb-4.mb-md-0
              p Las preguntas se preestablecen mediante un guion organizado y estructurado para que el entrevistador elija las respuestas y se aplica, de igual forma, a toda la muestra. Su sistematización es más sencilla, lo que permite un mejor análisis y los resultados son más objetivos y confiables. Así mismo, se convierte en un formato poco flexible, con bajo nivel de adaptabilidad y poca profundidad en las respuestas obtenidas.
            .col-md-12
              figure
                img(src='@/assets/curso/temas/tema2/img11.jpg', alt='Imagen decorativa')
          .row(numero="6" titulo="Entrevistas semiestructuradas")
            .col-md-12.mb-4.mb-md-0
              p Son más flexibles que las estructuradas porque gran parte de las preguntas se pueden ajustar al entrevistado. Aquí el entrevistador puede adaptar las preguntas a medida que se va desarrollando la entrevista sin modificar el guion previamente establecido; es posible aclarar respuestas, ampliar conceptos, profundizar términos, entre otros.
            .col-md-12
              figure
                img(src='@/assets/curso/temas/tema2/img12.jpg', alt='Imagen decorativa')
          .row(numero="7" titulo="Entrevistas no estructuradas")
            .col-md-12.mb-4.mb-md-0
              p Son más flexibles e informales que la estructurada y semiestructurada. Se planifica con la finalidad que pueda adaptarse completamente a las condiciones del entrevistado sin perder su foco. Los participantes (entrevistador y entrevistados) pueden profundizar los conceptos y ampliar las respuestas, hasta el punto de desviarse del plan original. En este proceso, se pueden presentar “lagunas” en la información obtenida que puede variar de un entrevistador a otro.
            .col-md-12
              figure
                img(src='@/assets/curso/temas/tema2/img12.jpg', alt='Imagen decorativa')
          .row(numero="8" titulo="Encuesta")
            .col-md-12.mb-4.mb-md-0
              p Utilizada para obtener información de un grupo de individuos sobre diversos temas mediante una serie de preguntas organizadas. A diferencia de la entrevista, no requieren de una interacción directa entre el entrevistador y el entrevistado, incluso, puede desarrollarse telefónicamente y #[i online]. Puede tener preguntas abiertas y cerradas, así:               
              .tarjeta--container.row.mb-5
                .col-md.tarjeta.colortarj-3.p-5                  
                  ul.lista-ul.mb-0
                    li.mb-0
                      i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                      p.mb-0 #[b Pregunta abierta]
                  p ¿Cómo le pareció el diseño del producto?
                  ul.lista-ul.mb-0
                    li.mb-0
                      i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                      p.mb-0 #[b Pregunta dicotómica]
                  p ¿Cómo le pareció el producto? 
                  p a. Bueno o b. Malo
                  ul.lista-ul.mb-0
                    li.mb-0
                      i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                      p.mb-0 #[b Pregunta de opción múltiple]
                  p ¿Cómo le pareció el producto?
                  ol.lista-ol
                    li
                      span.text-bold a. 
                      | Excelente.
                    li
                      span.text-bold b. 
                      | Bueno.
                    li
                      span.text-bold c. 
                      | Regular.
                    li
                      span.text-bold d. 
                      | Malo.

                .col-md.tarjeta.colortabs.p-5
                  p ¿El producto suplió perfectamente sus necesidades?
                  ol.lista-ol
                    li
                      span.text-bold a. 
                      | Nada satisfecho.
                    li
                      span.text-bold b. 
                      | Poco satisfecho.
                    li
                      span.text-bold c. 
                      | Neutral.
                    li
                      span.text-bold d. 
                      | Muy satisfecho.
                    li
                      span.text-bold e. 
                      | Totalmente satisfecho.

                .col-md.tarjeta.colortarj3.p-5                  
                  ul.lista-ul.mb-0
                    li.mb-0
                      i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                      | #[b Pregunta de orden de rangos]
                  p Coloque en orden de mayor a menor importancia las siguientes opciones, siendo 5 la más importante y 1 la menos importante para el producto:
                  ul.lista-ul
                    li
                      | ____Marca.
                    li
                      | ____Diseño.
                    li
                      | ____Empaque.
                    li
                      | ____Tamaño.
                    li
                      | ____Color.
                      

            .col-md-12
              figure
                img(src='@/assets/curso/temas/tema2/img13.jpg', alt='Imagen decorativa')
          .row(numero="9" titulo="<em>Focus Group</em>")
            .col-md-12.mb-4.mb-md-0
              p  Se desarrolla mediante un encuentro presencial o virtual con un grupo de personas y permite conocer de forma rápida lo que piensan los participantes del tema objeto de investigación, por lo general estudios de mercado. Se caracteriza porque:
              .cajon.colorpaso.p-3
                ul.lista-ul.mb-0
                  li.mb-0
                    i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                    | Se obtienen datos directamente del consumidor.
                  li.mb-0
                    i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                    | El moderador orienta las preguntas al grupo y dirige el encuentro para que los participantes puedan expresarse con naturalidad.
                  li.mb-0
                    i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                    | Tienen una duración limitada.
                  li.mb-0
                    i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                    | Los grupos pueden estar conformados entre 5 y 10 personas para un mejor control.
                  li.mb-0
                    i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                    | Normalmente, los miembros del grupo no se conocen entre sí. 
                  li.mb-0
                    i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                    | Son útiles para explorar al público objetivo antes de lanzar un producto o hacer un relanzamiento de marca.  
            .col-md-12
              figure
                img(src='@/assets/curso/temas/tema2/img14.jpg', alt='Imagen decorativa')
    Separador
    .row
      .col-xl-12
    #t_2_3.titulo-segundo.color-acento-contenido(data-aos="zoom-in-left")
      h2.my-5 2.3 Herramientas para la recolección de información

    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12
      p La recolección de información varía según el tipo de investigación que se esté desarrollando y las técnicas establecidas para tal fin; es así que, a continuación, se destacan los cuestionarios y las escalas de actitudes como dos herramientas de relevancia para la administración de la información que se obtiene:
  
    .row.align-items-center.mb-4
      .col-auto.pe-0.desktop(style="z-index:2")
        figure
          img(src='@/assets/curso/temas/tema1/imgtitulo.svg').m-auto
      .col-auto.bg-c8(style="z-index:1;color:#4B6280")
        .p-2
          h3.mb-0 Los cuestionarios

    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12
      p Los cuestionarios contienen un conjunto de preguntas para obtener, procesar y analizar información de la muestra o segmento de la población seleccionada. Este instrumento se utiliza mucho en la investigación cuantitativa de mercados, pues los datos pueden ser exactos para una correcta medición.

    .row.justify-content-center.align-items-center.mb-5
      .col-lg-10
        .cajon.color-secundario.p-3.mb-5
          .row.justify-content-center.align-items-center
            .col-lg-7
              p Para crear un cuestionario es importante tener en cuenta:
              ol.lista-ol--cuadro
                li
                .lista-ol--cuadro__vineta(style="color:#000000;")
                  span 1
                | Identificar qué información necesitamos obtener.
                li
                .lista-ol--cuadro__vineta(style="color:#000000;")
                  span 2
                | Determinar el tipo de pregunta.
                li
                .lista-ol--cuadro__vineta(style="color:#000000;")
                  span 3
                | Determinar la forma para recopilar la información, que puede ser presencial (encuesta personal) o virtual (formulario en línea).
                li
                .lista-ol--cuadro__vineta(style="color:#000000;")
                  span 4
                | Diseñar las preguntas con sus respectivas formas de respuesta y orden.
                li
                .lista-ol--cuadro__vineta(style="color:#000000;")
                  span 5
                | Realizar un test de prueba, antes de realizar la encuesta.
                li
                .lista-ol--cuadro__vineta(style="color:#000000;")
                  span 6
                | Realizar la encuesta.
            .col-lg-5
              figure
                img(src='@/assets/curso/temas/tema2/img15.jpg').m-auto
      .col-lg-10
        p Las preguntas juegan un papel importante para el cuestionario, pues su correcta elaboración garantizará que la respuesta permita obtener la información correcta. Entre los diferentes tipos de preguntas, se tienen:
    
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12.col-md-12.mb-4.mb-md-0(data-aos="flip-left")
        .titulo-sexto.color-acento-contenido.offset-0
          h5 Figura 2.
          span  #[i Tipos de preguntas ]

    .row.justify-content-center.align-items-center.mb-5
      .col-12.col-lg-12.desktop
        figure
          img(src='@/assets/curso/temas/tema2/img16.svg', alt='En la figura 2 se muestra una clasificación según su respuesta, función y contenido, de los tipos de preguntas utilizados en los cuestionarios.')

      .col-12.col-lg-12.movil
        figure
          img(src='@/assets/curso/temas/tema2/img16_1.svg', alt='En la figura 2 se muestra una clasificación según su respuesta, función y contenido, de los tipos de preguntas utilizados en los cuestionarios.')

    .row.justify-content-center.align-items-center.mb-5
      .col-lg-10
        .tarjeta.color-primario.p-3
          .row.justify-content-around.align-items-center
            .col-auto
              img(src="@/assets/curso/temas/tema2/img17.svg").img65
            .col
              .row.justify-content-between.align-items-center
                .col.mb-3.mb-sm-0
                  p.text-small.mb-0 Surveymonkey es una plataforma especializada para el desarrollo de encuestas en línea, muy útil, no solo para el diseño del cuestionario, sino también para la organización y graficación de los resultados, puedes encontrar más información sobre esta plataforma haciendo clic en el siguiente enlace, dar clic aquí.
                .col-sm-auto
                  a.boton.color-acento-botones(href="https://es.surveymonkey.com/" target="_blank")
                    span Enlace #[i web]
                    i.fas.fa-cloud-arrow-up

    .row.align-items-center.mb-4
      .col-auto.pe-0.desktop(style="z-index:2")
        figure
          img(src='@/assets/curso/temas/tema1/imgtitulo.svg').m-auto
      .col-auto.bg-c8(style="z-index:1;color:#4B6280")
        .p-2
          h3.mb-0 Las escalas de actitudes

    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12
      p   Las escalas de actitudes obtienen información a partir del análisis objetivo de las actitudes de la población. Implican procedimientos para darle un valor cuantitativo o medible a la aceptación o rechazo por parte de los implicados. Por ejemplo: si un encuestado responde que no está satisfecho con el servicio porque todos los días lo atiende mal, se le puede dar un valor de “2”, porque es “mala atención”, de esta forma, el resultado se convierte en cuantitativo y se puede medir.

      p La escala de Likert es un instrumento que, a diferencia de los cuestionarios, deben ser estandarizados y con una mejor preparación, para obtener los datos con mayor confiabilidad y validez. Se le da este nombre por el psicólogo Rensis Likert, quien distinguió entre una escala apropiada, que se deriva de respuestas colectivas a un grupo de ítems (ocho o más) y las respuestas son puntuadas en un rango de valores.

      p La escala de Likert tiene dos propiedades referidas para su medición, estas son:
    .tarjeta--container.row.mb-5
      .col-md.tarjeta.color-primario.p-5
        .row.justify-content-center.mb-4
          .col-4
            figure
              img(src='@/assets/curso/temas/tema2/img18.svg', alt='Imagen decorativa')
        h2.text-center Dirección de la respuesta
        p La cual puede ser negativa o positiva o neutral.
      .col-md.tarjeta.color-secundario.p-5
        .row.justify-content-center.mb-4
          .col-4
            figure
              img(src='@/assets/curso/temas/tema2/img19.svg', alt='Imagen decorativa')
        h2.text-center Intensidad de la respuesta
        p Que puede ser alta si la persona está convencida y que su actitud o comportamiento es justificado o baja si la persona no piensa así.
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-10
        p Para construir una encuesta con preguntas y respuestas basadas en la escala de Likert, se debe llevar a cabo el siguiente procedimiento:
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-10
        .cajon.colortarj3.p-3
          .row.justify-content-center.align-items-center
            .col-lg-5
              figure
                img(src='@/assets/curso/temas/tema2/img20.jpg').m-auto
            .col-lg-7
              ol.lista-ol--cuadro
                li
                .lista-ol--cuadro__vineta(style="color:#000000;")
                  span 1
                | Definir la actitud o variable que se va a medir.
                li
                .lista-ol--cuadro__vineta(style="color:#000000;")
                  span 2
                | Determinar los indicadores de la variable.
                li
                .lista-ol--cuadro__vineta(style="color:#000000;")
                  span 3
                | Determinar la dirección positiva o negativa.
                li
                .lista-ol--cuadro__vineta(style="color:#000000;")
                  span 4
                | Asignar los valores a cada ítem.
                li
                .lista-ol--cuadro__vineta(style="color:#000000;")
                  span 5
                | Distribuir los ítems en la encuesta.
                li
                .lista-ol--cuadro__vineta(style="color:#000000;")
                  span 6
                | Construir la escala final con base en los ítems seleccionados.
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-6
        p Algunas de las alternativas que se presentan en una escala Likert, son:
    .row.justify-content-center.align-items-center
      .col-lg-12.col-md-12.mb-4.mb-md-0(data-aos="flip-left")
        .titulo-sexto.color-acento-contenido.offset-0
          h5 Tabla 3.
          span  #[i  Alternativas de una escala Likert]
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12.mb-4        
        .tabla-a.color-acento-contenido
          table
            thead
              tr
                th.text-center Línea de Opciones
                th.text-center Alternativa 1
                th.text-center Alternativa 2
                th.text-center Alternativa 3
                th.text-center Alternativa 4
                th.text-center Alternativa 5
            tbody
              tr 
                td.text-center 1 >
                td.text-center Muy de acuerdo.	
                td.text-center De acuerdo.	
                td.text-center Ni de acuerdo ni en desacuerdo.	
                td.text-center En desacuerdo.	
                td.text-center Muy en desacuerdo.
              tr 
                td.text-center 2 >	
                td.text-center Totalmente de acuerdo.	
                td.text-center De acuerdo.	
                td.text-center Neutral.	
                td.text-center En desacuerdo.	
                td.text-center Totalmente en desacuerdo.
              tr 
                td.text-center 3 >	
                td.text-center Definitivamente sí.	
                td.text-center Probablemente sí.	
                td.text-center Indeciso.	
                td.text-center Probablemente no.	
                td.text-center Definitivamente no.
              tr 
                td.text-center 4 >		
                td.text-center Completamente verdadero.
                td.text-center Verdadero.	
                td.text-center Ni falso ni verdadero.	
                td.text-center Falso.	                
                td.text-center Completamente falso.
              tr 
                td.text-center 5 >	
                td.text-center Mucho.	
                td.text-center Bastante.	
                td.text-center Neutral.	
                td.text-center Un poco.	
                td.text-center No, en lo absoluto.
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-10
        p A cada una de las alternativas se les asigna un valor o peso representado en un número, de manera que solo se pueda marcar una sola respuesta, de lo contrario, el dato no es válido. Por ejemplo:
    
    .row.justify-content-center.align-items-center
      .col-lg-12.col-md-12.mb-4.mb-md-0(data-aos="flip-left")
        .titulo-sexto.color-acento-contenido.offset-0
          h5 Tabla 4.
          span  #[i  Ejemplo escala Likert]
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12.mb-4        
        .tabla-a.color-acento-contenido
          table
            thead
              tr
                th.text-center N°
                th.text-center Pregunta	
                th.text-center Muy de acuerdo	
                th.text-center De acuerdo	
                th.text-center Ni de acuerdo ni en desacuerdo	
                th.text-center En desacuerdo	
                th.text-center Muy en desacuerdo
            tbody
              tr 
                td.text-center 1	
                td.text-center El cliente no comprendió las necesidades de la aplicación.	
                td.text-center 5
                td.text-center 4	
                td.text-center 3
                td.text-center 2
                td.text-center 1
              tr 
                td.text-center 2	
                td.text-center Al cliente le gusta el producto, pero no lo usa.
                td.text-center 5
                td.text-center 4	
                td.text-center 3
                td.text-center 2
                td.text-center 1


</template>

<script>
export default {
  name: 'Tema2',
  data: () => ({
    // variables de vue
  }),
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
  updated() {
    this.$aosRefresh()
  },
}
</script>

<style lang="sass"></style>
