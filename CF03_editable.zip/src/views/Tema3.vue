<template lang="pug">
.curso-main-container.pb-3
  BannerInterno
  .container.tarjeta.tarjeta--blanca.p-4.p-md-5.mb-5
    .titulo-principal.color-acento-contenido
      .titulo-principal__numero
        span 3
      h1 #[i Insights] y medios digitales
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12
      p Un #[i insight] es un ítem, clave o elemento que lleva a la solución de un problema, es un dato que nos recomienda cómo resolver la incógnita. No es una solución, es un ítem que dirige hacia esa solución. En el área de los contenidos digitales, los #[i insights] son muy importantes porque facilitan la labor del diseñador al momento de producir una pieza gráfica, o del estratega de #[i marketing] para realizar una buena toma de decisión.  
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-10
        .bloque-texto-g.color-primario.p-3.p-sm-4.p-md-5
          .bloque-texto-g__img(
            :style="{'background-image':`url(${require('@/assets/curso/temas/tema3/img1.jpg')})`}"
          )
          .bloque-texto-g__texto.p-4
            p.mb-0 Un #[i insight] es el resultado de un proceso previo de investigación de marca, de aspectos relevantes del consumidor y es una de las mejores formas de conectar con ellos. Si se encuentra el insight adecuado, es posible encontrar una gran oportunidad para solucionar el problema de mercadeo a través de información que es difícil de identificar o no es fácilmente observable con otro método de investigación. Los aspectos no tangibles de la marca en relación con el consumidor, generando oportunidades para nuevos productos o estrategias.
      .col-lg-10
        p Las ventajas de aplicar #[i insights] en las estrategias de #[i marketing] y comunicación digital son muchas y muy diversas, pues permiten enriquecer el producto añadiendo valor en perspectiva del cliente, incluyendo sus demandas y necesidades y, de esta forma, encaminar los esfuerzos de la empresa en fidelizar al consumidor.
    Separador
    .row
      .col-xl-12
    #t_3_1.titulo-segundo.color-acento-contenido(data-aos="zoom-in-left")
      h2.my-5 3.1 Usos del #[i insights]
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12
      p Es importante hacer una buena investigación de marca y del consumidor para identificar el #[i insight] en toda estrategia de #[i marketing] digital. Antes de difundir cualquier producto del portafolio es importante hacer una buena selección del #[i insight] que identifica el producto. Un #[i insight], en el #[i marketing] es la base para la creación sólida de marcas, productos y servicios digitales, porque permiten entender el por qué las personas hacen lo que hacen y toman ciertas decisiones. 

      p El mercado actual es más competitivo y el consumidor tiene una mayor posibilidad de acceder a la información usando internet, por tanto, las marcas deben ser dinámicas, posicionarse rápidamente en la mente de los consumidores y usar el #[i insight] como herramienta de conocimiento del cliente. Los siguientes son sus usos complementarios y relevantes:
    .row.justify-content-center.align-items-center.mb-5
      .col-md-6.col-xl.mb-4.mb-xl-0
        .tarjeta--boton.color-primario.p-4
          .row.justify-content-center.mb-3
            .col-7
              figure
                img(src='@/assets/curso/temas/tema3/img2.svg', alt='Imagen decorativa')

          p.text-center Permiten la creación de estrategias innovadoras o de productos de una forma diferente.
          

      .col-md-6.col-xl.mb-4.mb-xl-0
        .tarjeta--boton.color-primario.p-4
          .row.justify-content-center.mb-3
            .col-7
              figure
                img(src='@/assets/curso/temas/tema3/img3.svg', alt='Imagen decorativa')

          p.text-center Identifican aquellos aspectos que pueden “tocar la fibra sensible” del cliente y así, adaptar el producto de acuerdo con sus necesidades.
      .col-md-6.col-xl.mb-4.mb-xl-0
        .tarjeta--boton.color-primario.p-4
          .row.justify-content-center.mb-3
            .col-7
              figure
                img(src='@/assets/curso/temas/tema3/img4.svg', alt='Imagen decorativa')

          p.text-center Es un aspecto no tangible de la marca, por lo que lleva a la generación de ideas innovadoras y disruptivas con los equipos de trabajo. 
      .col-md-6.col-xl.mb-4.mb-xl-0
        .tarjeta--boton.color-primario.p-4
          .row.justify-content-center.mb-3
            .col-7
              figure
                img(src='@/assets/curso/temas/tema3/img5.svg', alt='Imagen decorativa')

          p.text-center En la comunicación, le da impacto a los planes y las estrategias de #[i marketing]. 
          
      .col-md-6.col-xl.mb-4.mb-xl-0
        .tarjeta--boton.crd.color-primario.p-4
          .row.justify-content-center.mb-3
            .col-7
              figure
                img(src='@/assets/curso/temas/tema3/img6.svg', alt='Imagen decorativa')

          p.text-center.mb-3 Es fundamental para la estrategia de publicidad.
          
          
    Separador
    .row
      .col-xl-12
    #t_3_2.titulo-segundo.color-acento-contenido(data-aos="zoom-in-left")
      h2.my-5 3.2 Variables para definir #[i insights]
    
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12
      p No hay procesos “cerrados” o únicos en la definición de #[i insights], pues puede ser tan variado como el tipo de producto o servicio que se quiere promover. El desarrollo propuesto en este apartado incluye los siguientes momentos:
    .bg_tarj_3
      .row.justify-content-center.mb-5
        .col-xl-3.col-lg-7.col-md-9.col-11.mb-4.mb-xl-0
          .crd_hover_txt(data-aos="flip-left")
            .crd_hover_txt--img
              figure
                img(src="@/assets/curso/temas/tema3/img12.png", alt="alt")
            .crd_hover_txt--body.crd_hover_txt--body2
              .icono  
                img(src="@/assets/curso/temas/tema1/flecha.svg", alt="Imagen decorativa")
              h4.mb-3 Observación
              p.mb-0 Qué “le gustaría” al consumidor, sus sentimientos, necesidades, deseos y decisiones en un momento específico.
        .col-xl-3.col-lg-7.col-md-9.col-11.mb-4.mb-xl-0
          .crd_hover_txt(data-aos="flip-left")
            .crd_hover_txt--img
              figure
                img(src="@/assets/curso/temas/tema3/img13.png", alt="alt")
            .crd_hover_txt--body.crd_hover_txt--body2
              .icono  
                img(src="@/assets/curso/temas/tema1/flecha.svg", alt="Imagen decorativa")
              h4.mb-3 Motivación
              p.mb-0 Se identifica por qué o la justificación del consumidor para seleccionar el producto o hacer la compra.
        .col-xl-3.col-lg-7.col-md-9.col-11.mb-4.mb-xl-0
          .crd_hover_txt(data-aos="flip-left")
            .crd_hover_txt--img
              figure
                img(src="@/assets/curso/temas/tema3/img14.png", alt="alt")
            .crd_hover_txt--body.crd_hover_txt--body2
              .icono  
                img(src="@/assets/curso/temas/tema1/flecha.svg", alt="Imagen decorativa")
              h4.mb-3 Freno
              p.mb-0 Es el argumento o barrera que puede bloquear o cambiar la motivación del consumidor.
        .col-xl-3.col-lg-7.col-md-9.col-11.mb-4.mb-xl-0
          .crd_hover_txt(data-aos="flip-left")
            .crd_hover_txt--img
              figure
                img(src="@/assets/curso/temas/tema3/img15.png", alt="alt")
            .crd_hover_txt--body.crd_hover_txt--body2
              .icono  
                img(src="@/assets/curso/temas/tema1/flecha.svg", alt="Imagen decorativa")
              h4.mb-3 Repuesta de marca
              p.mb-0 Resultado obtenido del contacto del consumidor con el producto y sus beneficios.

    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12
      p El #[i insight] permite conectar, descubrir, inspirar y transformar una estrategia de #[i marketing] y, en especial, el #[i marketing] digital así:
    
    .row.justify-content-center.align-items-center.mb-5      
      .col-lg-3(data-aos="flip-left")
        .tarjeta-avatar
          img(src='@/assets/curso/temas/tema3/img16.svg' alt='AvatarTop')
          .tarjeta.colorcol1.w-100
            .p-4
              h3.text-center Conectar
              p Hablar en un mismo lenguaje, conectar la vivencia personal.
              br
      .col-lg-3(data-aos="flip-left")
        .tarjeta-avatar
          img(src='@/assets/curso/temas/tema3/img17.svg' alt='AvatarTop')
          .tarjeta.colorcol1.w-100
            .p-4
              h3.text-center Descubrir
              p El #[i insight] puede ayudar a descubrir cómo siente el consumidor.
              
      .col-lg-3(data-aos="flip-left")
        .tarjeta-avatar
          img(src='@/assets/curso/temas/tema3/img18.svg' alt='AvatarTop')
          .tarjeta.colorcol1.w-100
            .p-4
              h3.text-center Inspirar
              p Dan el tono justo, son fuentes de inspiración para cualquier acto de comunicación e innovación.
      .col-lg-3(data-aos="flip-left")
        .tarjeta-avatar
          img(src='@/assets/curso/temas/tema3/img19.svg' alt='AvatarTop')
          .tarjeta.colorcol1.w-100
            .p-4
              h3.text-center Transformar
              p El #[i insight] determinad el tipo de comunicación, tanto en su forma cómo en su contenido.
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12
      p Algunas veces los #[i consumer insight] se crean ficticiamente, porque pueden ser el resultado de una afirmación empírica o basado en el conocimiento previo del consumidor. Para que un descubrimiento pueda ser considerado #[i insight], debe cumplir con las siguientes características:

    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12.col-md-12.mb-4.mb-md-0(data-aos="flip-left")
        .titulo-sexto.color-acento-contenido.offset-0
          h5 Figura 3.
          span  #[i Características insight]

    .row.justify-content-center.align-items-center.mb-5
      .col-12.col-lg-12.desktop
        figure
          img(src='@/assets/curso/temas/tema3/img20.svg', alt='En la figura 3 se muestran las características de un insight verdadero, las cuales son real, alcance, relevante, inspirador y simple')

      .col-12.col-lg-12.movil
        figure
          img(src='@/assets/curso/temas/tema3/img21.svg', alt='En la figura 3 se muestran las características de un insight verdadero, las cuales son real, alcance, relevante, inspirador y simple')

    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12
      p En definitiva, el primer paso para llegar a un consumer #[i insight], o un #[i insight] en el #[i marketing] digital, es que se pueda convertir en una estrategia y no solo encontrar un hecho, sino que se debe tener creatividad para convertir el descubrimiento en una idea que sintetice toda la información.

    Separador
    .row
      .col-xl-12
    #t_3_3.titulo-segundo.color-acento-contenido(data-aos="zoom-in-left")
      h2.my-5 3.3 Herramientas digitales para #[i #[i insight]] de #[i marketing]

    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12
      p Para definir los #[i insights], los profesionales del #[i marketing] deben apoyarse en diferentes herramientas que permitan el análisis de las variables descritas. En ese sentido, las herramientas digitales cumplen un papel importante en todo el desarrollo de la creación de #[i insights]. 
      p Las herramientas digitales son los programas que pueden usarse para sintetizar la información obtenida de la investigación de mercados, analizarla y tomar decisiones adecuadas. La posibilidad de innovar con el uso de estas herramientas, resulta un factor importante.

      p Las funciones principales de las herramientas digitales son:
    
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12.col-md-12.mb-4.mb-md-0(data-aos="flip-left")
        .titulo-sexto.color-acento-contenido.offset-0
          h5 Figura 4.
          span  #[i Funciones principales de las herramientas digitales]

    .row.justify-content-center.align-items-center.mb-5
      .col-12.col-lg-12.desktop
        figure
          img(src='@/assets/curso/temas/tema3/img22.svg', alt='En la figura 4 se muestran las funciones principales de las herramientas digitales, como son facilitar la realización de actividades y la interacción de las personas entre otras.')


      .col-12.col-lg-12.movil
        figure
          img(src='@/assets/curso/temas/tema3/img22_1.svg', alt='En la figura 4 se muestran las funciones principales de las herramientas digitales, como son facilitar la realización de actividades y la interacción de las personas entre otras.')
    Separador
    .row
      .col-xl-12
    #t_3_4.titulo-segundo.color-acento-contenido(data-aos="zoom-in-left")
      h2.my-5 3.4 Clasificación de herramientas digitales

    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12
      p Las herramientas digitales, aplicadas a diferentes medios de comunicación y de #[i marketing], permiten superar las barreras del espacio y el tiempo, así mismo permiten que dos o más personas interactúan por medio de mensajes escritos o audiovisuales, en tiempo real o asincrónico. Además, posibilitan el intercambio de información de manera rápida y efectiva.
    
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-10
          .bloque-texto-g.color-primario.p-3.p-sm-4.p-md-5
            .bloque-texto-g__img(
              :style="{'background-image':`url(${require('@/assets/curso/temas/tema3/img23.jpg')})`}"
            )
            .bloque-texto-g__texto.p-4
              p.mb-0 En educación, las herramientas digitales son un gran apoyo para enriquecer el contenido que se desarrolla durante la clase, además, con el uso de internet, los aprendices pueden acceder a cualquier tipo de información con la orientación de sus docentes. Por parte de los instructores, las herramientas digitales se usan en la investigación de cualquier tema o área y permite a los investigadores compartir su información y hacer recopilaciones.

    .row.justify-content-center.align-items-center.mb-5
      .col-lg-10
        p Las herramientas digitales, sin duda alguna, tienen muy variados y numerosos usos de acuerdo con el área de interés o profesional en el cual sean aplicadas. Entre ellas, hay dos grandes grupos, principalmente:
    
    .tarjeta--container.row.mb-5
      .col-md.tarjeta.color-primario.p-5
        .row.justify-content-center.mb-4
          .col-6
            figure
              img(src='@/assets/curso/temas/tema3/img24.svg', alt='Imagen decorativa')
        p #[b Soluciones de escritorio]: son aquellas herramientas que se deben instalar localmente en cada computador para que puedan funcionar. Usualmente, requieren de la compra de una licencia o bien pueden instalarse de forma gratuita según la marca. Por ejemplo, Microsoft Office (pago por licencia) y Open Office (gratuito).
      .col-md.tarjeta.color-secundario.p-5
        .row.justify-content-center.mb-4
          .col-6
            figure
              img(src='@/assets/curso/temas/tema3/img25.svg', alt='Imagen decorativa')
        p #[b Soluciones #[i online]]: como su nombre lo indica, son aquellas que funcionan a través de un servidor y con conexión a internet. El funcionamiento es similar a las soluciones de escritorio, solo que puedes acceder a ellas desde cualquier lugar siempre que se esté conectado a internet. Por ejemplo: Google Apps (documentos, hojas de cálculo, etc.) u Office #[i Online] (Word, Excel, etc.). A diferencia de las soluciones de escritorio, las herramientas ofimáticas en línea permiten trabajar de forma colaborativa en un mismo documento, compartir información, etc.
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-6
        p Las siguientes son las herramientas digitales más representativas:
    
    .BGIMG01.p-5.mb-5
      SlyderA(tipo="b")(data-aos="zoom-in-up")
        .row
          .col-md-6.mb-4.mb-md-0
            h4 Procesador de texto
            p Usado para la redacción de informes, cartas, contenidos, memorandos, folletos sencillos, manuales, tesis, etc. Si el documento es en línea, se pueden introducir animaciones, videos, entre otros. 
            ul.lista-ul.mb-0
              li.mb-0
                i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                | Word (Office).
              li.mb-0
                i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                | Writer (Open Office).
              li.mb-0
                i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                | Documentos (Google).

          .col-md-6
            figure
              img(src='@/assets/curso/temas/tema3/img26.jpg', alt='Imagen decorativa')
        .row
          .col-md-6.mb-4.mb-md-0
            h4 Hoja de cálculo
            p Su función principal es generar planillas con balances, control de gastos, estados de cuenta, manejos contables, etc.
            ul.lista-ul.mb-0
              li.mb-0
                i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                | Excel (Office).
              li.mb-0
                i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                | Calc (Open Office).
              li.mb-0
                i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                | Hoja de cálculo (Google).


          .col-md-6
            figure
              img(src='@/assets/curso/temas/tema3/img27.jpg', alt='Imagen decorativa')
        .row
          .col-md-6.mb-4.mb-md-0
            h4 Bases de datos
            p Permite la creación y administración de datos del usuario, control de inventarios, consulta de registros, entre otras aplicaciones.
            ul.lista-ul.mb-0
              li.mb-0
                i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                | Access (Office).
              li.mb-0
                i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                | Base (Open Office).
          .col-md-6
            figure
              img(src='@/assets/curso/temas/tema3/img28.jpg', alt='Imagen decorativa')
        .row
          .col-md-6.mb-4.mb-md-0
            h4 Presentaciones
            p Permite la creación de presentaciones basadas en diapositivas o #[i slides] para la exposición de información, gráficos, infografías, videos, animaciones, gráficos, etc.
            ul.lista-ul.mb-0
              li.mb-0
                i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                | PowerPoint (Office).
              li.mb-0
                i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                | Impress (Open Office).
              li.mb-0
                i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                | Presentaciones (Google).
          .col-md-6
            figure
              img(src='@/assets/curso/temas/tema3/img29.jpg', alt='Imagen decorativa')
        .row
          .col-md-6.mb-4.mb-md-0
            h4 Videoconferencias y conversaciones en línea
            p Son plataformas que permiten la comunicación audiovisual y bidireccional que se desarrolla en tiempo real y a distancia para establecer la conversación entre dos o más participantes. Estas plataformas cuentan con herramientas complementarias para el trabajo en equipo, ideación y cocreación.
            ul.lista-ul.mb-0
              li.mb-0
                i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                | Zoom.
              li.mb-0
                i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                | Google Meet.
              li.mb-0
                i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                | Microsoft Teams.
              li.mb-0
                i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                | Skype.
              li.mb-0
                i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                | WhatsApp.
              li.mb-0
                i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                | Telegram.
              li.mb-0
                i.fas.fa-circle.fa-xs(style="color:#A3BFE4")
                | Messenger.

          .col-md-6
            figure
              img(src='@/assets/curso/temas/tema3/img30.jpg', alt='Imagen decorativa')
    .row.justify-content-center.align-items-center.mb-5
      .col-lg-10
        p El siguiente video amplía el concepto de herramientas digitales y su impacto en el entorno de las personas, se invita a observarlo para ampliar sus conocimientos al respecto:
    
    .row.justify-content-center.align-items-center.md-5   
      .col-lg-12(data-aos="fade-left")     
        figure
          .video          
            iframe(width="560" height="315" src="https://www.youtube.com/embed/cmJDv36nogY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen)
    Separador
    .row
      .col-xl-12
    #t_3_5.titulo-segundo.color-acento-contenido(data-aos="zoom-in-left")
      h2.my-5 3.5 Uso de las herramientas digitales en los #[i insights]

    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12
      p Entre las principales herramientas para obtener #[i insights] se encuentran la analítica, la escucha digital, el monitoreo de la experiencia, la minería de datos y la investigación de mercados, cada una con sus características específicas que se describen a continuación:
    
    SlyderB.slyder-b-img.mb-5.p-5(:datos="datosLineaTiempoB")

    .row.justify-content-center.align-items-center.mb-5
      .col-lg-12
        p Estas herramientas no son efectivas por sí solas, deben integrarse para que el resultado sea más funcional y de alto valor. Es así como, realizando cruces de información de canales digitales con los telefónicos o físicos, se pueden generar análisis de datos más profundos para obtener una medida integral para la gestión de la experiencia del cliente.

</template>

<script>
export default {
  name: 'Tema3',
  data: () => ({
    // variables de vue
    datosLineaTiempoB: [
      {
        titulo: 'Analítica digital',
        texto:
          'Permite identificar el volumen de los usuarios que interactúan en un portal de comercio electrónico, redes sociales, correos e incluso apps, de esta forma, se puede definir qué tipo de usuarios tiene una marca determinada, permitiendo que se puedan evidenciar sus necesidades frente a la marca o el producto y qué elementos pueden añadirle valor, generando rentabilidad.<br> En un sitio web la analítica permite comprender los hábitos de los clientes, frecuencias de uso. En las redes sociales los datos se enfocan a presentar la efectividad de contenidos de acuerdo con la reacción de los públicos y la calificación del contenido.',
        imagen: require('@/assets/curso/temas/tema3/img31.jpg'),
      },
      {
        titulo: 'Escucha digital',
        texto:
          'Hace referencia al seguimiento y análisis de las interacciones y conversaciones que sostiene la audiencia en un canal digital o en un segmento del mercado. <br><br>Permite identificar oportunidades para conseguir nuevos públicos, alcanzar nuevos mercados y alinearse con diferentes tendencias comunicativas en estos canales; conocer, de forma cercana a un público y su relación con la marca, uso detallado del producto o el sentimiento que tiene hacia la organización. <br><br>Facilita el desarrollo de otras acciones como programas de reputación, prevención de crisis, automatización de procesos de atención, mejoramiento de la comunicación con los públicos, entre otros.',
        imagen: require('@/assets/curso/temas/tema3/img32.jpg'),
      },
      {
        titulo: 'Monitoreo de experiencia digital',
        texto:
          'Consiste en explorar el comportamiento del consumidor en los diferentes canales digitales de la organización y su reacción ante la recepción de información como email <em>marketing</em>.<br><br>Los resultados obtenidos a partir del análisis previo a estos eventos, servirán para identificar oportunidades para el mejoramiento de la experiencia del usuario.<br><br>Asimismo, estos chequeos mejoran el entendimiento del intercambio de información entre clientes para influenciar sobre su comportamiento en los canales digitales. Algunos de estos chequeos se hacen con mapas de calor, <em>journeys</em> de navegación, <em>tracking</em> de usuarios, entre otros.',
        imagen: require('@/assets/curso/temas/tema3/img33.jpg'),
      },
      {
        titulo: 'Minería de datos',
        texto:
          'Es un proceso que se realiza con la finalidad de encontrar patrones y correlaciones en conjuntos de datos y de esta forma, predecir resultados. En el caso de los canales digitales sirve para obtener la frecuencia y hábitos de compra de los usuarios según las categorías de productos, incluso obtener información del perfil sociodemográfico de cada cliente.<br><br> Es posible anticiparse a determinados eventos, caídas del sistema, precompras o adquisición de productos, por ejemplo, en una promoción sería posible predecir cuáles serán los productos con mayor venta y a través de qué canales.',
        imagen: require('@/assets/curso/temas/tema3/img34.jpg'),
      },
      {
        titulo: 'Investigación de mercados y usuarios',
        texto:
          'Permite ejecutar un mayor número de acciones relacionadas con los hábitos de compra y comportamientos del usuario, dejando a la empresa una serie de estrategias basadas en un <em>insight</em> de alto valor.<br><br>Entre las prácticas que se derivan de esta herramienta, tenemos: consultas en bases de datos de instituciones gubernamentales y no gubernamentales, grupos focales, entrevistas a profundidad y encuestas, tanto en campo como en contenidos <em>online</em>.Los resultados pueden integrarse en bases de datos para una posterior construcción de modelos de segmentación o modelos predictivos.',
        imagen: require('@/assets/curso/temas/tema3/img35.jpg'),
      },
    ],
  }),
  mounted() {
    this.$nextTick(() => {
      this.$aosRefresh()
    })
  },
  updated() {
    this.$aosRefresh()
  },
}
</script>

<style lang="sass"></style>
