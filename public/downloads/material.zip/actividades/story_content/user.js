function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5W96YGDPn7O":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

